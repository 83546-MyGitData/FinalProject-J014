const Books =  [
      {
        "id": "1",
        "name": "Stocks",
        "price": 5,
        "isInCart": false,
        "wishlist": false,
        "count": 0
      },
      {
        "id": "2",
        "name": "Economy",
        "price": 5,
        "isInCart": false,
        "wishlist": false,
        "count": 0
      },
      {
        "id": "3",
        "name": "Politics",
        "price": 20,
        "isInCart": false,
        "wishlist": false,
        "count": 0
      },
      {
        "id": "4",
        "name": "Stocks",
        "price": 19,
        "isInCart": false,
        "wishlist": false,
        "count": 0
      },
      {
        "id": "5",
        "name": "Economy",
        "price": 19,
        "isInCart": false,
        "wishlist": false,
        "count": 0
      },
      {
        "id": "6",
        "name": "Politics",
        "price": 12,
        "isInCart": false,
        "wishlist": false,
        "count": 0
      },
      {
        "id": "7",
        "name": "Novel",
        "price": 7,
        "isInCart": false,
        "wishlist": false,
        "count": 0
      },
      {
        "id": "8",
        "name": "Economy",
        "price": 6,
        "count": 0,
        "wishlist": false,
        "isInCart": false
      },
      {
        "id": "9",
        "name": "Tech",
        "price": 5,
        "count": 0,
        "wishlist": false,
        "isInCart": false
      },
      {
        "id": "10",
        "name": "Religion",
        "price": 18,
        "count": 0,
        "wishlist": false,
        "isInCart": false
      },
      {
        "id": "11",
        "name": "Politics",
        "price": 8,
        "wishlist": false,
        "isInCart": false,
        "count": 0
      },
      {
        "id": "12",
        "name": "Novel",
        "price": 10,
        "isInCart": false,
        "wishlist": false,
        "count": 0
      },
      {
        "id": "13",
        "name": "Tech",
        "price": 5,
        "count": 0,
        "wishlist": false,
        "isInCart": false
      },
      {
        "id": "14",
        "name": "Tech",
        "price": 3,
        "count": 0,
        "wishlist": false,
        "isInCart": false
      }
    ];

export default Books;