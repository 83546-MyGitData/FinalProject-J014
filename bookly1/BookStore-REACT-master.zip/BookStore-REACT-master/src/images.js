import Novel from "./images/Books/Novel.jpg";
import History from "./images/Books/History.jpg";
import science from "./images/Books/science.jpg";
import economy from "./images/Books/Stock.jpg";
import Gold from "./images/Books/book4.jpg"

const images = [ Novel , History , science , economy , Gold ,Novel ,science , History ,Novel ,economy , science ,economy , Gold , Gold ,science];
export default images;
