import Navbar from '../components/navbar';

export function Cart(){
    return (
        <>
        <Navbar/>
        <h1>Cart</h1>
        </>
    )
}

export default Cart