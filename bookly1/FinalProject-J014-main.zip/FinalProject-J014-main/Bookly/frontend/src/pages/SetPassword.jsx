import React from 'react'

export const SetPassword = () => {
  return (
    <div>SetPassword</div>
  )
}
