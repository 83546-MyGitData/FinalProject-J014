import Navbar from '../components/navbar';

export function Orders(){
    return (
        <div>
        <Navbar/>
        </div>
    )
}

export default Orders