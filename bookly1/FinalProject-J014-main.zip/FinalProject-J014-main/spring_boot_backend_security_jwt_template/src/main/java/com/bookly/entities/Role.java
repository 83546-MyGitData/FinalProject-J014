package com.bookly.entities;

public enum Role {
	ROLE_CUSTOMER, ROLE_ADMIN
}
